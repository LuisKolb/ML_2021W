# ML_2021W


### ex2

#### required packages
```
pandas  
sklearn
```